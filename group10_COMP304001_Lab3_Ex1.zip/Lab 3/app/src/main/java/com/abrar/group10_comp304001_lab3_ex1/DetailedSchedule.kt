package com.abrar.group10_comp304001_lab3_ex1

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room

class DetailedSchedule : AppCompatActivity() {
    lateinit var database: AirLinesDatabase
    lateinit var adapter: FlightDetailedInfoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailed_schedule)

        val airlineName = intent.getStringExtra("airlineName").toString()

        database = Room.databaseBuilder(
            applicationContext,
            AirLinesDatabase::class.java, "database-name"
        ).build()

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        database.AirLinesDAO().getAirLinesWithName(airlineName).observe(this, Observer { flightList ->
            // Check if the flightList is not null
            flightList?.let {
                // Initialize the adapter with the flight list
                adapter = FlightDetailedInfoAdapter(it)
                recyclerView.adapter = adapter

                // Set item click listener
                adapter.setOnItemClickListener(object : FlightDetailedInfoAdapter.OnItemClickListener {
                    override fun onItemClick(position: Int) {
                        val intent = Intent(this@DetailedSchedule, DetailedSchedule::class.java)
                        intent.putExtra("airlineName", it[position].airlineName)
                        startActivity(intent)
                    }
                })
            }
        })
    }
}