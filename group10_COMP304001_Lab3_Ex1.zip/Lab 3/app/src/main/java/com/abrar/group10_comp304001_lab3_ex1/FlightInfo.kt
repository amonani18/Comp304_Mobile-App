package com.abrar.group10_comp304001_lab3_ex1

data class FlightInfo(
    val airlineName: String,
    val arrivalTime: String,
    val terminalNumber: String,
    val status: Boolean = true
)