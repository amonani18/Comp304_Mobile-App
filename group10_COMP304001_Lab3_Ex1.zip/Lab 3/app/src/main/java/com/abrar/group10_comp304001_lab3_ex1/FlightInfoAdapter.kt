package com.abrar.group10_comp304001_lab3_ex1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FlightInfoAdapter(private val flightList: List<AirLinesDB>) :
    RecyclerView.Adapter<FlightInfoAdapter.FlightInfoViewHolder>() {

    // Click listener interface
    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    private var listener: OnItemClickListener? = null

    // Setter method for listener
    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlightInfoViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.air_schedule_table_row, parent, false)
        return FlightInfoViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: FlightInfoViewHolder, position: Int) {
        val currentItem = flightList[position]

        holder.airlineNameTextView.text = currentItem.airlineName
        holder.arrivalTimeTextView.text = currentItem.arrivalTime
        holder.terminalNumberTextView.text = currentItem.terminalNumber

        // Set click listener
        holder.itemView.setOnClickListener {
            listener?.onItemClick(position)
        }
    }

    override fun getItemCount(): Int = flightList.size

    // ViewHolder class
    class FlightInfoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val airlineNameTextView: TextView = itemView.findViewById(R.id.airlineName)
        val arrivalTimeTextView: TextView = itemView.findViewById(R.id.arrivalTime)
        val terminalNumberTextView: TextView = itemView.findViewById(R.id.terminalNumber)
    }
}
